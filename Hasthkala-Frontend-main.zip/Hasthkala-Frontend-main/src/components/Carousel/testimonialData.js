import R1 from '../../assets/Reviews/1.jpg';
import R2 from '../../assets/Reviews/2.jpg';
import R3 from '../../assets/Reviews/3.jpg';
import R4 from '../../assets/Reviews/4.jpg';
import R5 from '../../assets/Reviews/5.jpg';
import R6 from '../../assets/Reviews/6.jpg';
import R7 from '../../assets/Reviews/7.jpg';

const data = [
    {
        img:R1,
        name:"Gayatri Joshi",
        msg:"I liked the cards they are wonderful",
    },
    {
        img:R6,
        name:"Dwaipayan Dasgupta",
        msg:"Recently ordered a wallet card!!!💙💙💙 it is jst a awesome. I am as a designer , i am jst pleased by his work and thinking process. Such a nice way to represent the massage. Keep it up bro. Long way to good.",
    },
    {
        img:R4,
        name:"Anamika Sarkar",
        msg:"I had ordered a wallet card which was 100percent customized as per my choice .And it came the same way as i expected",
    },
    {
        img:R2,
        name:"Zikra Naeem Tarkash",
        msg:"I've purchased Wallet card with illustration and it's so beautiful and perfect💯 in affordable budget he gave me free Spotify scanner also and some freebies ❤ the card looks amazing and it got delivered within few days ☺ will definitely suggest others to give it a try .. ",
    },
    {
        img:R5,
        name:"Swapna Nayak",
        msg:"They send me tha free card also...I like the product so much.. thank you 😄",
    },
    {
        img:R3,
        name:"Samiksha Pandey",
        msg:"I am truly impressed and satisfied with the product and service. great job 👍THANK YOU ",
    },
    {
        img:R7,
        name:"Sakshi Jagdale",
        msg:"My husband liked this amazing wallet card he appreciated ❤ thanks ",
    },

]

export default data;